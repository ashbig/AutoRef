/*
 * Gene.java
 *
 * Created on January 18, 2002, 2:27 PM
 */

package edu.harvard.med.hip.metagene.core;

import java.util.*;

/**
 *
 * @author  dzuo
 * @version 
 */
public class Gene {
    public static final String GENE = "GENE";
    public static final String FAMILY = "FAMILY";
    
    private int hipGeneId; // it is hip_gene_id if gene type is GENE; it is parent_id if gene type is FAMILY
    private String symbol;
    private int qualityidSymbol;
    private String name;   // it is formal_name_value if gene type is GENE; it is parent_value if gene type is FAMILY
    private int qualityidName;
    private String date;
    private int locusid;
    private Vector nicknames;
    private Vector information;
    private String type;
    
    /** Creates new Gene */
    public Gene(int id, String symbol, int qualSymbol, String name, int qualName, String date, int locusid, String type) {
        this.hipGeneId = id;
        this.symbol = symbol;
        this.qualityidSymbol = qualSymbol;
        this.name = name;
        this.qualityidName = qualName;
        this.date = date;
        this.locusid = locusid;
        this.type = type;
    } 
 
    public int getHipGeneId() {
        return hipGeneId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSymbol() {
        return symbol;
    }
    
    public void setNicknames(Vector nicknames) {
        this.nicknames = nicknames;
    }
    
    public Vector getNicknames() {
        return nicknames;
    }
    
    public String getNicknamesString() {
        String rt = "";
        
        if(nicknames == null)
            return rt;
        
        for(int i=0; i<nicknames.size(); i++) {
            String nickname = (String)nicknames.elementAt(i);
            
            if(i == 0)
                rt = nickname;
            else 
                rt = rt+", "+nickname;
        }
        
        return rt;
    }
    
    public void setInformation(Vector information) {
        this.information = information;
    }
    
    public String getGosString() {
        if(information == null)
            return "";
        
        String go = null;
        for(int i=0; i<information.size(); i++) {
            Geneinfo info = (Geneinfo)information.elementAt(i);
            if(Geneinfo.GO.equals(info.getType())) {
                if(go == null)
                    go = info.getValue();
                else
                    go = go+", "+info.getValue();
            }
        }
        
        return go;
    }
    
    // generate refSeq_NM with blank space in the middle to fit display
    public String getRefSeq_NM() {
        
        if(information == null)
            return " ";
        
        String refSeq_NM = " ";
        String tmp;
        for(int i=0; i<information.size(); i++) {
            Geneinfo info = (Geneinfo)information.elementAt(i);
            if(info.getType().equals(Geneinfo.REFSEQ_NM)) {
                if(info.getRefSeq_NM_order()==1){
                    tmp = info.getValue();
                    refSeq_NM = tmp.substring(0,3) + " " + tmp.substring(3);
                    break;
                }
            }
        }

        return refSeq_NM;
    } 
    
    // generate refSeq_NM without blank space in the middle
    public String getRefSeq_NM2() {
        
        if(information == null)
            return "";
        
        String refSeq_NM = "";
        for(int i=0; i<information.size(); i++) {
            Geneinfo info = (Geneinfo)information.elementAt(i);
            if(info.getType().equals(Geneinfo.REFSEQ_NM)) {
                if(info.getRefSeq_NM_order()==1){
                    refSeq_NM = info.getValue();
                    break;
                }
            }
        }

        return refSeq_NM;
    } 
    
    
    // not in current use
    public String getProteomesString() {
        if(information == null)
            return "";

        String proteome = null;
        for(int i=0; i<information.size(); i++) {
            Geneinfo info = (Geneinfo)information.elementAt(i);
            if(Geneinfo.GO.equals(info.getType())) {
                if(proteome == null)
                    proteome = info.getValue();
                else
                    proteome = proteome+", "+info.getValue();
            }
        }
        
        return proteome;
    }
    
    public int getLocusid() {
        return locusid;
    }
    
    public String getType() {
        return type;
    }
}
