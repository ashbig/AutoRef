/*
 *
 *
 * Created on May 25, 2001, 11:03 AM
 */

package edu.harvard.med.hip.metagene;

/**
 *
 * @author  jmunoz
 * @version
 */
public class Constants {
    /*
     * Application constants
     */
    
        
    /*
     * Keys used in the session/request
     */
    // key used to find user object in session.
    public static final String USER_KEY = "USER";    
    
    /** Creates new Constants */
    private Constants() {
    }
    
}
